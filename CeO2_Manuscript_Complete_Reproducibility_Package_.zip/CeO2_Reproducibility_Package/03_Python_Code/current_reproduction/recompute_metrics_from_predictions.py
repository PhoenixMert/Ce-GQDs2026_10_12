#!/usr/bin/env python3
from pathlib import Path
import numpy as np, pandas as pd
ROOT=Path(__file__).resolve().parents[2]; A=ROOT/"04_Analysis_Data"; OUT=ROOT/"09_Recalculated"; OUT.mkdir(exist_ok=True)
def r2(y,p):
    y=np.asarray(y,float); p=np.asarray(p,float); d=np.sum((y-y.mean())**2)
    return 1-np.sum((y-p)**2)/d if d else np.nan
def rmse(y,p): return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))
def mae(y,p): return float(np.mean(np.abs(np.asarray(y)-np.asarray(p))))
def mape(y,p):
    y=np.asarray(y,float); p=np.asarray(p,float); m=np.abs(y)>0
    return float(np.mean(np.abs((p[m]-y[m])/y[m]))*100)
def freq_summary(df, groups):
    out=[]
    for keys,g in df.groupby(groups,dropna=False):
        keys=(keys,) if not isinstance(keys,tuple) else keys
        per=[]
        for _,q in g.groupby("frequency_Hz"):
            y=q.experimental.to_numpy(float); p=q.predicted.to_numpy(float)
            per.append((rmse(y,p)/np.mean(y)*100,mae(y,p),mape(y,p)))
        y=g.experimental.to_numpy(float); p=g.predicted.to_numpy(float)
        row=dict(zip(groups,keys)); row.update(R2=r2(y,p),NRMSE_mean_pct=np.mean([x[0] for x in per]),
            MAE_mean=np.mean([x[1] for x in per]),MAPE_mean_pct=np.mean([x[2] for x in per])); out.append(row)
    return pd.DataFrame(out)
sp=pd.read_csv(A/"Sparse_Grid"/"sparse_primary_predictions.csv")
primary=sp[sp.seed.isin([0,42])].copy()
freq_summary(primary,["budget_measured","target","method"]).to_csv(OUT/"recalculated_sparse_primary_summary.csv",index=False)
parts=[pd.read_csv(A/"LOFO"/f) for f in ["primary_lofo_predictions.csv","dl_lofo_predictions.csv"] if (A/"LOFO"/f).exists()]
lofo=pd.concat(parts,ignore_index=True); lofo["region"]=np.where(lofo.frequency_Hz.isin([10000,10000000]),"endpoint_extrapolation","interior_interpolation")
freq_summary(lofo,["target","method","region"]).to_csv(OUT/"recalculated_lofo_region_summary.csv",index=False)
def direct(df,yc,pc):
    out=[]
    for m,g in df.groupby("method"):
        y=g[yc].to_numpy(float); p=g[pc].to_numpy(float); per=[]
        if "frequency_Hz" in g.columns:
            for _,q in g.groupby("frequency_Hz"):
                yy=q[yc].to_numpy(float); pp=q[pc].to_numpy(float); per.append(rmse(yy,pp)/np.mean(yy)*100)
        out.append([m,r2(y,p),np.mean(per) if per else rmse(y,p)/np.mean(y)*100,mape(y,p)])
    return pd.DataFrame(out,columns=["method","R2","NRMSE_mean_pct","MAPE_pct"])
rs=pd.read_csv(A/"Derived_Rs_Gp_Nss"/"rs_accumulation_reconstructed_points.csv")
direct(rs[(rs.budget_measured==5)&(rs.voltage_V>=1.0)],"Rs_exp_ohm","Rs_recon_ohm").to_csv(OUT/"recalculated_Table5_Rs.csv",index=False)
gp=pd.read_csv(A/"Derived_Rs_Gp_Nss"/"gp_over_omega_reconstructed_points.csv")
direct(gp[gp.budget_measured==5],"Gp_over_omega_exp","Gp_over_omega_recon").to_csv(OUT/"recalculated_Table5_Gp_over_omega.csv",index=False)
n=pd.read_csv(A/"Derived_Rs_Gp_Nss"/"nss_profiles_sparse_reconstruction.csv")
direct(n[n.budget_measured==5],"Nss_exp","Nss_recon").to_csv(OUT/"recalculated_Nss_metrics.csv",index=False)
print("Recalculated outputs:",OUT)
