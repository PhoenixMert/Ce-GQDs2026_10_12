#!/usr/bin/env python3
from pathlib import Path
import pandas as pd, matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[2]; A=ROOT/"04_Analysis_Data"; OUT=ROOT/"09_Recalculated"/"figures"; OUT.mkdir(parents=True,exist_ok=True)
s=pd.read_csv(A/"Sparse_Grid"/"sparse_primary_summary.csv")
for target in ["C","G"]:
    for metric in ["R2_mean","NRMSE_mean_pct"]:
        fig,ax=plt.subplots(figsize=(6.5,4.5))
        for method,g in s[s.target==target].groupby("method"):
            g=g.sort_values("budget_measured",ascending=False); ax.plot(g.budget_measured,g[metric],marker="o",label=method)
        ax.set_xlabel("Measured frequencies"); ax.set_ylabel("R²" if metric=="R2_mean" else "NRMSE (%)"); ax.legend(); fig.tight_layout()
        fig.savefig(OUT/f"Figure8_{target}_{metric}.png",dpi=300); plt.close(fig)
n=pd.read_csv(A/"Derived_Rs_Gp_Nss"/"nss_profiles_sparse_reconstruction.csv"); n=n[n.budget_measured==5]
fig,ax=plt.subplots(figsize=(6.5,4.5)); ref=n.drop_duplicates("voltage_V").sort_values("voltage_V"); ax.plot(ref.voltage_V,ref.Nss_exp,label="Reference",lw=2)
for m,g in n.groupby("method"): g=g.sort_values("voltage_V"); ax.plot(g.voltage_V,g.Nss_recon,label=m)
ax.set_xlabel("Bias voltage (V)"); ax.set_ylabel("Nss"); ax.legend(); fig.tight_layout(); fig.savefig(OUT/"Figure11_Nss.png",dpi=300); plt.close(fig)
