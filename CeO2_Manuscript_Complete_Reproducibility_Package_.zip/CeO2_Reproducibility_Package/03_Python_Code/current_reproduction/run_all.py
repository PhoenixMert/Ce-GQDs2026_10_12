#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
H=Path(__file__).resolve().parent
for s in ["run_sparse_reconstruction.py","recompute_metrics_from_predictions.py","verify_manuscript_numbers.py","regenerate_numerical_figures.py"]:
    print("\n==>",s); subprocess.run([sys.executable,str(H/s)],check=True)
