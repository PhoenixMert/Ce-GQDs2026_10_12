#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]; A=ROOT/"04_Analysis_Data"
s=pd.read_csv(A/"Sparse_Grid"/"sparse_primary_summary.csv")
def v(b,t,m,c): return float(s[(s.budget_measured==b)&(s.target==t)&(s.method==m)][c].iloc[0])
checks=[("5f G PCHIP R2",v(5,"G","PCHIP","R2_mean"),.9959,5e-5),("5f C Linear R2",v(5,"C","Linear","R2_mean"),.9869,5e-5),("5f C ET R2",v(5,"C","ET","R2_mean"),.9852,5e-5),("5f G XGB NRMSE",v(5,"G","XGB","NRMSE_mean_pct"),139.84,.0051)]
d=pd.read_csv(A/"Derived_Rs_Gp_Nss"/"sparse_derived_parameters_summary.csv"); r=d[(d.budget_measured==5)&(d.method=="PCHIP")].iloc[0]
checks += [("PCHIP Rs R2",float(r.Rs_accum_R2),.9952,5e-5),("PCHIP Nss R2",float(r.Nss_R2),.9582,5e-5)]
q=pd.read_csv(A/"Nss_Sensitivity"/"sensitivity_aggregate_summary.csv").iloc[0]
checks += [("median |S_C|",float(q.median_abs_elasticity_C),3.29,.0051),("median |S_G|",float(q.median_abs_elasticity_G),.225,.00051)]
bad=0
for name,a,e,tol in checks:
    ok=abs(a-e)<=tol; print("PASS" if ok else "FAIL",name,a,"expected",e); bad+=0 if ok else 1
raise SystemExit(1 if bad else 0)
