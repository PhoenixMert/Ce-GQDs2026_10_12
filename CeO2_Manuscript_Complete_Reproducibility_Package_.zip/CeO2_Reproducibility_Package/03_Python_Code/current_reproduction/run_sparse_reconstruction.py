#!/usr/bin/env python3
from pathlib import Path
import numpy as np, pandas as pd
from scipy.interpolate import interp1d, PchipInterpolator
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from xgboost import XGBRegressor
ROOT=Path(__file__).resolve().parents[2]; DATA=ROOT/"02_Raw_Data"/"experimental_cv_gv_long.csv"; OUT=ROOT/"09_Recalculated"; OUT.mkdir(exist_ok=True)
GRIDS={13:[10,30,50,70,100,200,300,500,1000,2000,3000,5000,10000],9:[10,30,50,100,300,700,2000,5000,10000],7:[10,30,100,300,1000,3000,10000],5:[10,50,300,2000,10000]}
df=pd.read_csv(DATA)
if "frequency_kHz" not in df: df["frequency_kHz"]=df.frequency_Hz/1000
def model(n):
    if n=="RF": return RandomForestRegressor(n_estimators=300,bootstrap=True,oob_score=True,max_depth=None,min_samples_leaf=1,random_state=42,n_jobs=-1)
    if n=="ET": return ExtraTreesRegressor(n_estimators=250,bootstrap=False,max_depth=None,min_samples_leaf=1,random_state=42,n_jobs=-1)
    return XGBRegressor(n_estimators=100,learning_rate=.05,max_depth=3,tree_method="hist",subsample=.9,colsample_bytree=1.,reg_alpha=0,reg_lambda=1,random_state=42,objective="reg:squarederror",n_jobs=-1)
rows=[]
for b,grid in GRIDS.items():
    trall=df[df.frequency_kHz.isin(grid)].copy(); teall=df[~df.frequency_kHz.isin(grid)].copy()
    for target in ["C","G"]:
        for meth in ["Linear","PCHIP"]:
            for v,q in df.groupby("voltage_V"):
                tr=q[q.frequency_kHz.isin(grid)].sort_values("frequency_Hz"); te=q[~q.frequency_kHz.isin(grid)].sort_values("frequency_Hz")
                x=np.log10(tr.frequency_Hz.to_numpy(float)); y=np.log10(tr[target].to_numpy(float))
                fn=interp1d(x,y,kind="linear",fill_value="extrapolate") if meth=="Linear" else PchipInterpolator(x,y,extrapolate=True)
                pred=10**fn(np.log10(te.frequency_Hz.to_numpy(float)))
                for (_,r),p in zip(te.iterrows(),pred): rows.append([b,target,meth,0,r.frequency_Hz,r.frequency_kHz,r.voltage_V,r[target],p])
        Xtr=np.c_[trall.voltage_V,np.log10(trall.frequency_Hz)]; Xte=np.c_[teall.voltage_V,np.log10(teall.frequency_Hz)]; ytr=np.log10(trall[target])
        for meth in ["RF","ET","XGB"]:
            m=model(meth); m.fit(Xtr,ytr); pred=10**m.predict(Xte)
            for (_,r),p in zip(teall.iterrows(),pred): rows.append([b,target,meth,42,r.frequency_Hz,r.frequency_kHz,r.voltage_V,r[target],p])
pd.DataFrame(rows,columns=["budget_measured","target","method","seed","frequency_Hz","frequency_kHz","voltage_V","experimental","predicted"]).to_csv(OUT/"rerun_sparse_primary_predictions.csv",index=False)
print("Saved",OUT/"rerun_sparse_primary_predictions.csv")
