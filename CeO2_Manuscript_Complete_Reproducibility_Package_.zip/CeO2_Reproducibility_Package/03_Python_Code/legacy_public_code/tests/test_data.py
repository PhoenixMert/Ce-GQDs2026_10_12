from src.data_loader import load_experimental_long, validate_dataset
from src.config import FREQUENCIES_HZ, N_BIAS

def test_dataset_shape_and_grid():
    rows = load_experimental_long()
    assert len(rows) == len(FREQUENCIES_HZ) * N_BIAS
    assert validate_dataset(rows) == []
