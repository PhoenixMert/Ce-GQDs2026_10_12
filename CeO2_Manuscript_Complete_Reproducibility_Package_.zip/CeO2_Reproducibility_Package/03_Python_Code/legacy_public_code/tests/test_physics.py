import math
from src.physics import series_resistance, g_over_omega, nss_hill_coleman

def test_g_over_omega_definition():
    assert math.isclose(g_over_omega(2*math.pi*1e6*1e-11, 1e6), 1e-11, rel_tol=1e-12)

def test_series_resistance_positive():
    assert series_resistance(1e-10, 1e-4, 1e6) > 0

def test_hill_coleman_positive():
    assert nss_hill_coleman(1e-11) > 0
