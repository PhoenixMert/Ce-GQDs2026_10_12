
#!/usr/bin/env python3
import csv
import math
from collections import defaultdict
import numpy as np

from src.config import PROJECT_ROOT
from src.lofo import build_matrices
from src.metrics import regression_metrics

CI_F = 3e-10
Q_C = 1.602176634e-19
CONTACT_DIAMETER_CM = 0.1  # 1 mm
AREA_CM2 = math.pi * (CONTACT_DIAMETER_CM/2.0)**2
HC_FACTOR = 0.402

PREDICTION_FILES = (
    PROJECT_ROOT/"results/predictions/primary_lofo_predictions.csv",
    PROJECT_ROOT/"results/predictions/dl_lofo_predictions.csv",
)

def hill_coleman(C, G, frequencies_hz):
    C = np.asarray(C, dtype=float)
    G = np.asarray(G, dtype=float)
    f = np.asarray(frequencies_hz, dtype=float)
    omega = 2*np.pi*f
    gpw = (omega[:, None] * G * CI_F**2) / (
        G**2 + (omega[:, None] * (CI_F-C))**2
    )
    idx = np.argmax(gpw, axis=0)
    peak = gpw[idx, np.arange(gpw.shape[1])]
    nss = peak / (HC_FACTOR * Q_C * AREA_CM2)
    return nss, peak, f[idx]

def main():
    frequencies, voltages, Cexp, Gexp = build_matrices()
    exp_nss, exp_peak, exp_pf = hill_coleman(Cexp, Gexp, frequencies)

    rows = []
    for path in PREDICTION_FILES:
        if not path.exists():
            raise FileNotFoundError(
                f"Missing {path}. Run scripts 03 and 07 before Hill-Coleman Nss."
            )
        with open(path, newline="", encoding="utf-8") as f:
            rows.extend(csv.DictReader(f))

    methods = sorted({r["method"] for r in rows})
    profiles = []
    metrics = []

    for method in methods:
        lookup = defaultdict(dict)
        for r in rows:
            if r["method"] != method:
                continue
            f = int(float(r["frequency_Hz"]))
            v = float(r["voltage_V"])
            lookup[(f, v)][r["target"]] = float(r["predicted"])

        Cpred = np.empty_like(Cexp)
        Gpred = np.empty_like(Gexp)
        for i, f in enumerate(frequencies):
            for j, v in enumerate(voltages):
                d = lookup[(int(f), float(v))]
                Cpred[i, j] = d["C"]
                Gpred[i, j] = d["G"]

        pred_nss, _, _ = hill_coleman(Cpred, Gpred, frequencies)
        m = regression_metrics(exp_nss, pred_nss, scale=1.0)
        metrics.append({
            "Method": method,
            "R2": m["R2"],
            "MAE_eV-1_cm-2": m["MAE"],
            "RMSE_eV-1_cm-2": m["RMSE"],
            "MAPE_percent": m["MAPE"],
        })
        for v, e, p in zip(voltages, exp_nss, pred_nss):
            profiles.append({
                "Voltage_V": float(v),
                "Experimental": float(e),
                "Method": method,
                "Nss_predicted_eV-1_cm-2": float(p),
            })

    exp_rows = []
    for v, n, peak, pf in zip(voltages, exp_nss, exp_peak, exp_pf):
        exp_rows.append({
            "voltage_V": float(v),
            "Nss_HillColeman_eV-1_cm-2": float(n),
            "Gp_over_omega_max_F": float(peak),
            "peak_frequency_Hz": int(pf),
            "peak_frequency_kHz": float(pf/1000.0),
        })

    outputs = (
        (PROJECT_ROOT/"results/nss/experimental_hill_coleman_nss.csv", exp_rows),
        (PROJECT_ROOT/"results/nss/all_methods_hill_coleman_profiles.csv", profiles),
        (PROJECT_ROOT/"results/nss/all_methods_hill_coleman_metrics.csv", metrics),
    )
    for path, data in outputs:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(data[0].keys()))
            w.writeheader()
            w.writerows(data)

    i_max = int(np.argmax(exp_nss))
    i_min = int(np.argmin(exp_nss))
    print(f"Nss min: {exp_nss[i_min]:.6e} at V={voltages[i_min]:.2f} V")
    print(f"Nss max: {exp_nss[i_max]:.6e} at V={voltages[i_max]:.2f} V")
    print("Nss methods:", ", ".join(methods))
    print("Saved experimental, all-method profiles, and metrics.")

if __name__ == "__main__":
    main()
