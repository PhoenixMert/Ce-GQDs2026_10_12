
#!/usr/bin/env python3
import csv
from collections import defaultdict
from src.config import PROJECT_ROOT

FREQUENCIES_KHZ = (100, 1000, 5000, 10000)
METHOD_ORDER = ("Linear","PCHIP","RF","ET","XGB","GRU","LSTM")

def read_rows(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def write(path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader(); w.writerows(rows)

def main():
    cg = read_rows(PROJECT_ROOT/"results/metrics/primary_lofo_metrics.csv")
    cg += read_rows(PROJECT_ROOT/"results/metrics/dl_lofo_metrics.csv")
    rs = read_rows(PROJECT_ROOT/"results/metrics/rs_lofo_metrics.csv")
    nss = read_rows(PROJECT_ROOT/"results/nss/all_methods_hill_coleman_metrics.csv")

    t3=[]; t4=[]
    for target, dest in (("C",t3),("G",t4)):
        for fk in FREQUENCIES_KHZ:
            for method in METHOD_ORDER:
                r=next(x for x in cg if x["target"]==target and x["method"]==method
                       and int(round(float(x["frequency_kHz"])))==fk)
                dest.append({
                    "Frequency_kHz": fk, "Method": method,
                    "R2": f"{float(r['R2']):.4f}",
                    "RMSE": f"{float(r['RMSE']):.2f}",
                    "MAE": f"{float(r['MAE']):.2f}",
                    "MAPE_percent": f"{float(r['MAPE']):.2f}",
                })

    t5=[]
    for fk in FREQUENCIES_KHZ:
        for method in METHOD_ORDER:
            r=next(x for x in rs if x["method"]==method
                   and int(round(float(x["frequency_kHz"])))==fk)
            t5.append({
                "Frequency_kHz": fk, "Method": method,
                "R2": f"{float(r['R2']):.4f}",
                "NRMSE_percent": f"{float(r['NRMSE_percent']):.2f}",
                "NMAE_percent": f"{float(r['NMAE_percent']):.2f}",
                "MAPE_percent": f"{float(r['MAPE_percent']):.2f}",
            })

    nss_map={r["Method"]:r for r in nss}
    t7=[]
    for method in METHOD_ORDER:
        r=nss_map[method]
        label="LIN" if method=="Linear" else method
        t7.append({
            "Method":label,
            "R2":f"{float(r['R2']):.4f}",
            "MAE_eV-1_cm-2":f"{float(r['MAE_eV-1_cm-2']):.5E}",
            "RMSE_eV-1_cm-2":f"{float(r['RMSE_eV-1_cm-2']):.5E}",
            "MAPE_percent":f"{float(r['MAPE_percent']):.2f}",
        })

    out=PROJECT_ROOT/"results/tables"
    write(out/"Table3_CV_FINAL.csv", list(t3[0].keys()), t3)
    write(out/"Table4_GV_FINAL.csv", list(t4[0].keys()), t4)
    write(out/"Table5_RsV_FINAL.csv", list(t5[0].keys()), t5)
    write(out/"Table7_Nss_FINAL.csv", list(t7[0].keys()), t7)
    print("Generated final Tables 3, 4, 5 and 7.")

if __name__=="__main__":
    main()
