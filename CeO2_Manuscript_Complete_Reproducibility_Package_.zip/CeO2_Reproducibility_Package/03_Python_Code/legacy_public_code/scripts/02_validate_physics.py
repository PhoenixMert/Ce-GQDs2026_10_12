#!/usr/bin/env python3
from collections import defaultdict
from src.data_loader import load_experimental_long, validate_dataset
from src.physics import series_resistance

SELECTED = (100_000, 1_000_000, 5_000_000, 10_000_000)

def main():
    rows = load_experimental_long()
    errors = validate_dataset(rows)
    if errors:
        raise SystemExit("Dataset validation failed:\n- " + "\n- ".join(errors))

    by_f = defaultdict(list)
    for r in rows:
        by_f[r["frequency_Hz"]].append(
            series_resistance(r["C_F"], r["G_S"], r["frequency_Hz"])
        )

    print("Canonical physics validation: PASS")
    print("Mean experimental Rs at manuscript frequencies:")
    for f in SELECTED:
        mean_rs = sum(by_f[f]) / len(by_f[f])
        print(f"  {f/1000:g} kHz: {mean_rs:.5f} ohm")

if __name__ == "__main__":
    main()
