#!/usr/bin/env python3
from collections import Counter
from src.data_loader import load_experimental_long, validate_dataset

def main():
    rows = load_experimental_long()
    errors = validate_dataset(rows)
    print(f"Rows: {len(rows)}")
    print(f"Frequencies: {len(set(r['frequency_Hz'] for r in rows))}")
    print(f"Bias points/frequency: {Counter(r['frequency_Hz'] for r in rows).most_common(1)[0][1]}")
    if errors:
        raise SystemExit("Dataset validation failed:\n- " + "\n- ".join(errors))
    print("Dataset validation: PASS")

if __name__ == "__main__":
    main()
