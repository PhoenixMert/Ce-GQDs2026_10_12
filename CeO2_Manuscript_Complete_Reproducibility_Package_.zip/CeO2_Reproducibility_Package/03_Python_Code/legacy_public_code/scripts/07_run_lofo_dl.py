
#!/usr/bin/env python3
import csv

from src.config import PROJECT_ROOT, RANDOM_SEED
from src.lofo import build_matrices
from src.metrics import regression_metrics
from src.models.recurrent import predict_lofo_sequence

METHODS = ("GRU", "LSTM")

def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

def main():
    frequencies, voltages, C, G = build_matrices()
    predictions = []
    metrics = []
    logs = []

    for method in METHODS:
        for held_idx, held_freq in enumerate(frequencies):
            c_pred, g_pred, info = predict_lofo_sequence(
                method, frequencies, voltages, C, G, held_idx, seed=RANDOM_SEED
            )

            for target, y_true, y_pred, scale in (
                ("C", C[held_idx], c_pred, 1e12),
                ("G", G[held_idx], g_pred, 1e6),
            ):
                m = regression_metrics(y_true, y_pred, scale=scale)
                metrics.append({
                    "target": target,
                    "frequency_Hz": int(held_freq),
                    "frequency_kHz": held_freq/1000.0,
                    "method": method,
                    **m,
                })
                for v, yt, yp in zip(voltages, y_true, y_pred):
                    predictions.append({
                        "target": target,
                        "frequency_Hz": int(held_freq),
                        "frequency_kHz": held_freq/1000.0,
                        "voltage_V": float(v),
                        "method": method,
                        "experimental": float(yt),
                        "predicted": float(yp),
                    })

            logs.append({
                "frequency_Hz": int(held_freq),
                "frequency_kHz": held_freq/1000.0,
                "method": method,
                **info,
            })
            print(
                f"{method} {held_freq/1000:g} kHz | "
                f"C R2={metrics[-2]['R2']:.4f} | G R2={metrics[-1]['R2']:.4f}"
            )

    write_csv(PROJECT_ROOT/"results/predictions/dl_lofo_predictions.csv", predictions)
    write_csv(PROJECT_ROOT/"results/metrics/dl_lofo_metrics.csv", metrics)
    write_csv(PROJECT_ROOT/"results/metrics/dl_training_log.csv", logs)
    print("Saved DL predictions, metrics, and training logs.")

if __name__ == "__main__":
    main()
