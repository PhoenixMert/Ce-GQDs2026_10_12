#!/usr/bin/env python3
import csv
from pathlib import Path

from src.config import PROJECT_ROOT
from src.lofo import run_lofo_primary

METHODS = ("Linear", "PCHIP", "RF", "ET", "XGB")
TARGETS = ("C", "G")

def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

def main():
    all_predictions, all_metrics = [], []
    for target in TARGETS:
        for method in METHODS:
            print(f"Running {target} / {method} ...")
            pred, met = run_lofo_primary(method, target)
            all_predictions.extend(pred)
            all_metrics.extend(met)

    write_csv(PROJECT_ROOT/"results/predictions/primary_lofo_predictions.csv", all_predictions)
    write_csv(PROJECT_ROOT/"results/metrics/primary_lofo_metrics.csv", all_metrics)
    print("Saved LOFO predictions and metrics.")

if __name__ == "__main__":
    main()
