
#!/usr/bin/env python3
import csv
from collections import defaultdict
from src.config import PROJECT_ROOT
from src.physics import series_resistance
from src.metrics import regression_metrics

PREDICTION_FILES = (
    PROJECT_ROOT/"results/predictions/primary_lofo_predictions.csv",
    PROJECT_ROOT/"results/predictions/dl_lofo_predictions.csv",
)

def main():
    rows = []
    for path in PREDICTION_FILES:
        if not path.exists():
            raise FileNotFoundError(
                f"Missing {path}. Run scripts 03 and 07 before reconstructing Rs."
            )
        with open(path, newline="", encoding="utf-8") as f:
            rows.extend(csv.DictReader(f))

    paired = defaultdict(dict)
    for r in rows:
        key = (r["method"], int(float(r["frequency_Hz"])), float(r["voltage_V"]))
        paired[key][r["target"]] = {
            "experimental": float(r["experimental"]),
            "predicted": float(r["predicted"]),
        }

    out_pred = []
    grouped = defaultdict(lambda: {"y": [], "p": []})

    for (method, freq, voltage), d in sorted(paired.items()):
        if "C" not in d or "G" not in d:
            continue
        Cexp = d["C"]["experimental"]; Gexp = d["G"]["experimental"]
        Cpred = d["C"]["predicted"]; Gpred = d["G"]["predicted"]

        r_exp = series_resistance(Cexp, Gexp, freq)
        r_pred = series_resistance(Cpred, Gpred, freq)

        out_pred.append({
            "frequency_Hz": freq,
            "frequency_kHz": freq/1000.0,
            "voltage_V": voltage,
            "method": method,
            "Rs_experimental_ohm": r_exp,
            "Rs_predicted_ohm": r_pred,
        })
        grouped[(method, freq)]["y"].append(r_exp)
        grouped[(method, freq)]["p"].append(r_pred)

    out_metrics = []
    for (method, freq), d in sorted(grouped.items()):
        m = regression_metrics(d["y"], d["p"], scale=1.0)
        mean_rs = sum(d["y"]) / len(d["y"])
        out_metrics.append({
            "frequency_Hz": freq,
            "frequency_kHz": freq/1000.0,
            "method": method,
            "mean_experimental_Rs_ohm": mean_rs,
            "R2": m["R2"],
            "RMSE_ohm": m["RMSE"],
            "MAE_ohm": m["MAE"],
            "NRMSE_percent": m["RMSE"]/mean_rs*100.0,
            "NMAE_percent": m["MAE"]/mean_rs*100.0,
            "MAPE_percent": m["MAPE"],
        })

    for path, data in (
        (PROJECT_ROOT/"results/predictions/rs_lofo_predictions.csv", out_pred),
        (PROJECT_ROOT/"results/metrics/rs_lofo_metrics.csv", out_metrics),
    ):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(data[0].keys()))
            w.writeheader()
            w.writerows(data)

    methods = sorted({r["method"] for r in out_pred})
    print("Rs methods:", ", ".join(methods))
    print("Selected experimental mean Rs values:")
    for freq in (100_000, 1_000_000, 5_000_000, 10_000_000):
        vals = [x for x in out_metrics if x["frequency_Hz"] == freq]
        print(f"  {freq/1000:g} kHz: {vals[0]['mean_experimental_Rs_ohm']:.5f} ohm")
    print("Saved Rs predictions and metrics.")

if __name__ == "__main__":
    main()
