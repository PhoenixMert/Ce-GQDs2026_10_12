
#!/usr/bin/env python3
import csv
from pathlib import Path
import matplotlib.pyplot as plt
from PIL import Image
from src.config import PROJECT_ROOT

FREQS=(100,1000,5000,10000)
METHODS=("Linear","PCHIP","RF","ET")
LABELS={"Linear":"Linear","PCHIP":"PCHIP","RF":"RF","ET":"ET"}
COLORS={"Linear":"tab:orange","PCHIP":"tab:green","RF":"tab:red","ET":"tab:purple"}
LETTERS=("a","b","c","d")

plt.rcParams.update({
    "font.size":12, "axes.titlesize":12, "axes.labelsize":12,
    "xtick.labelsize":10, "ytick.labelsize":10, "legend.fontsize":9
})

def read(path):
    with open(path,newline="",encoding="utf-8") as f:
        return list(csv.DictReader(f))

def save_composite(panel_paths,out):
    imgs=[Image.open(p).convert("RGB") for p in panel_paths]
    w=max(im.width for im in imgs); h=max(im.height for im in imgs)
    canvas=Image.new("RGB",(2*w,2*h),"white")
    for i,im in enumerate(imgs):
        canvas.paste(im,((i%2)*w+(w-im.width)//2,(i//2)*h+(h-im.height)//2))
    canvas.save(out,format="TIFF",dpi=(600,600),compression="tiff_lzw")

def panel(ax,x,exp,curves,title,ylabel,legend_loc="upper left"):
    ax.plot(x,exp,linestyle="None",marker="o",markerfacecolor="none",
            markeredgecolor="black",markeredgewidth=.9,markersize=4.0,
            color="black",label="Experimental")
    for m,y in curves.items():
        ax.plot(x,y,color=COLORS[m],linewidth=1.4,label=LABELS[m])
    ax.set_title(title)
    ax.set_xlabel("Voltage (V)")
    ax.set_ylabel(ylabel)
    ax.tick_params(direction="in",top=True,right=True)
    ax.grid(True,alpha=.15,linewidth=.5)
    ax.legend(loc=legend_loc,frameon=False,ncol=2,handlelength=1.8,
              columnspacing=1.0,labelspacing=.25,handletextpad=.45)

def main():
    figdir=PROJECT_ROOT/"figures"
    datadir=figdir/"data"
    paneldir=figdir/"panels"
    for d in (figdir,datadir,paneldir): d.mkdir(parents=True,exist_ok=True)

    primary=read(PROJECT_ROOT/"results/predictions/primary_lofo_predictions.csv")
    rs=read(PROJECT_ROOT/"results/predictions/rs_lofo_predictions.csv")
    nss=read(PROJECT_ROOT/"results/nss/all_methods_hill_coleman_profiles.csv")

    for target,fig_no,ylabel,scale in (
        ("C","Figure6","Capacitance (pF)",1e12),
        ("G","Figure7","Conductance (µS)",1e6),
    ):
        panels=[]
        for f,letter in zip(FREQS,LETTERS):
            rr=[r for r in primary if r["target"]==target and int(round(float(r["frequency_kHz"])))==f]
            x=sorted({float(r["voltage_V"]) for r in rr})
            exp=[float(next(r["experimental"] for r in rr if float(r["voltage_V"])==v))*scale for v in x]
            curves={}
            for m in METHODS:
                curves[m]=[float(next(r["predicted"] for r in rr if r["method"]==m and float(r["voltage_V"])==v))*scale for v in x]

            csvpath=datadir/f"{fig_no}_{f}kHz.csv"
            with open(csvpath,"w",newline="",encoding="utf-8") as fh:
                w=csv.writer(fh); w.writerow(["Voltage_V","Experimental","Linear","PCHIP","RF","ET"])
                for i,v in enumerate(x):
                    w.writerow([v,exp[i],curves["Linear"][i],curves["PCHIP"][i],curves["RF"][i],curves["ET"][i]])

            fig,ax=plt.subplots(figsize=(6.1,4.55))
            panel(ax,x,exp,curves,f"({letter}) {f} kHz",ylabel)
            fig.tight_layout(pad=.7)
            p=paneldir/f"{fig_no}_{letter}_{f}kHz.tiff"
            fig.savefig(p,format="tiff",dpi=600,bbox_inches="tight",
                        pil_kwargs={"compression":"tiff_lzw"})
            plt.close(fig); panels.append(p)
        save_composite(panels,figdir/f"{fig_no}_FINAL_600dpi.tiff")

    # Figure 8: Rs
    panels=[]
    for idx,(f,letter) in enumerate(zip(FREQS,LETTERS)):
        rr=[r for r in rs if int(round(float(r["frequency_kHz"])))==f]
        x=sorted({float(r["voltage_V"]) for r in rr})
        exp=[float(next(r["Rs_experimental_ohm"] for r in rr if float(r["voltage_V"])==v)) for v in x]
        curves={}
        for m in METHODS:
            curves[m]=[float(next(r["Rs_predicted_ohm"] for r in rr if r["method"]==m and float(r["voltage_V"])==v)) for v in x]

        csvpath=datadir/f"Figure8_{f}kHz.csv"
        with open(csvpath,"w",newline="",encoding="utf-8") as fh:
            w=csv.writer(fh); w.writerow(["Voltage_V","Experimental","Linear","PCHIP","RF","ET"])
            for i,v in enumerate(x):
                w.writerow([v,exp[i],curves["Linear"][i],curves["PCHIP"][i],curves["RF"][i],curves["ET"][i]])

        fig,ax=plt.subplots(figsize=(6.1,4.55))
        panel(ax,x,exp,curves,f"({letter}) {f} kHz",r"$R_s$ ($\Omega$)",
              legend_loc="upper right" if idx==0 else "upper left")
        fig.tight_layout(pad=.7)
        p=paneldir/f"Figure8_{letter}_{f}kHz.tiff"
        fig.savefig(p,format="tiff",dpi=600,bbox_inches="tight",
                    pil_kwargs={"compression":"tiff_lzw"})
        plt.close(fig); panels.append(p)
    save_composite(panels,figdir/"Figure8_FINAL_600dpi.tiff")

    # Figure 9: Nss, manuscript-displayed methods
    x=sorted({float(r["Voltage_V"]) for r in nss})
    first_method=nss[0]["Method"]
    exp=[float(next(r["Experimental"] for r in nss if r["Method"]==first_method and float(r["Voltage_V"])==v)) for v in x]
    curves={}
    for m in METHODS:
        curves[m]=[float(next(r["Nss_predicted_eV-1_cm-2"] for r in nss if r["Method"]==m and float(r["Voltage_V"])==v)) for v in x]

    with open(datadir/"Figure9_Nss.csv","w",newline="",encoding="utf-8") as fh:
        w=csv.writer(fh); w.writerow(["Voltage_V","Experimental","Linear","PCHIP","RF","ET"])
        for i,v in enumerate(x):
            w.writerow([v,exp[i],curves["Linear"][i],curves["PCHIP"][i],curves["RF"][i],curves["ET"][i]])

    fig,ax=plt.subplots(figsize=(6.5,4.8))
    panel(ax,x,exp,curves,"",r"$N_{ss}$ (eV$^{-1}$ cm$^{-2}$)",legend_loc="best")
    fig.tight_layout(pad=.7)
    fig.savefig(figdir/"Figure9_FINAL_600dpi.tiff",format="tiff",dpi=600,
                bbox_inches="tight",pil_kwargs={"compression":"tiff_lzw"})
    plt.close(fig)
    print("Generated final figure-data CSVs and Figures 6-9.")

if __name__=="__main__":
    main()
