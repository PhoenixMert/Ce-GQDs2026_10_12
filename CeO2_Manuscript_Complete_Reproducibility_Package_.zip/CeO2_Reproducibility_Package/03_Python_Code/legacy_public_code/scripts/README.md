# Reproduction workflow

Run from the repository root in this order:

```bash
python scripts/01_prepare_dataset.py
python scripts/02_validate_physics.py
python scripts/03_run_lofo_primary_models.py
python scripts/07_run_lofo_dl.py
python scripts/05_reconstruct_rs.py
python scripts/09_compute_hill_coleman_nss.py
python scripts/10_generate_final_tables.py
python scripts/11_generate_final_figures.py
pytest -q
```

Outputs are stored under `results/` and `figures/`.
