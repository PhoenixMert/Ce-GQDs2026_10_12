import csv
import math
from pathlib import Path
import numpy as np

from .config import PROCESSED_DIR, RANDOM_SEED
from .data_loader import load_experimental_long
from .metrics import regression_metrics
from .models.interpolation import reconstruct_interpolation
from .models.ensemble import build_ensemble_model

def build_matrices():
    rows = load_experimental_long()
    frequencies = sorted({int(r["frequency_Hz"]) for r in rows})
    voltages = sorted({float(r["voltage_V"]) for r in rows})
    lookup = {(int(r["frequency_Hz"]), float(r["voltage_V"])): r for r in rows}

    C = np.array([[lookup[(f, v)]["C_F"] for v in voltages] for f in frequencies])
    G = np.array([[lookup[(f, v)]["G_S"] for v in voltages] for f in frequencies])
    return np.array(frequencies), np.array(voltages), C, G

def run_lofo_primary(method, target):
    frequencies, voltages, C, G = build_matrices()
    matrix = C if target == "C" else G
    scale = 1e12 if target == "C" else 1e6
    predictions, metrics_rows = [], []

    for held_idx, held_freq in enumerate(frequencies):
        if method in ("Linear", "PCHIP"):
            pred = reconstruct_interpolation(
                frequencies, matrix, held_idx, method.lower()
            )
        else:
            # Manuscript: input = [V, log10(f)], target = log10(C) or log10(G)
            x_train, y_train, x_test = [], [], []
            for i, f in enumerate(frequencies):
                for j, v in enumerate(voltages):
                    x = [v, math.log10(float(f))]
                    if i == held_idx:
                        x_test.append(x)
                    else:
                        x_train.append(x)
                        y_train.append(math.log10(float(matrix[i, j])))
            model = build_ensemble_model(method, RANDOM_SEED)
            model.fit(np.asarray(x_train), np.asarray(y_train))
            pred = 10.0 ** model.predict(np.asarray(x_test))

        y_true = matrix[held_idx]
        m = regression_metrics(y_true, pred, scale=scale)
        metrics_rows.append({
            "target": target,
            "frequency_Hz": int(held_freq),
            "frequency_kHz": held_freq / 1000.0,
            "method": method,
            **m,
        })
        for v, yt, yp in zip(voltages, y_true, pred):
            predictions.append({
                "target": target,
                "frequency_Hz": int(held_freq),
                "frequency_kHz": held_freq / 1000.0,
                "voltage_V": float(v),
                "method": method,
                "experimental": float(yt),
                "predicted": float(yp),
            })
    return predictions, metrics_rows
