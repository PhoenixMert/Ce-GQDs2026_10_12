from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
RESULTS_DIR = PROJECT_ROOT / "results"

FREQUENCIES_HZ = (
    10_000, 30_000, 50_000, 70_000, 90_000, 100_000, 200_000, 300_000,
    500_000, 700_000, 900_000, 1_000_000, 2_000_000, 3_000_000,
    5_000_000, 7_000_000, 10_000_000,
)
N_BIAS = 81
VOLTAGE_MIN = -2.5
VOLTAGE_MAX = 1.5
RANDOM_SEED = 42

# Manuscript/device constants
Q_C = 1.602176634e-19
DEVICE_AREA_CM2 = 0.00785

# This value appears explicitly in the archived corrected-data worksheet.
# It is retained only to reproduce/audit the legacy 1 MHz correction.
LEGACY_CORRECTION_RS_OHM = 120.0
