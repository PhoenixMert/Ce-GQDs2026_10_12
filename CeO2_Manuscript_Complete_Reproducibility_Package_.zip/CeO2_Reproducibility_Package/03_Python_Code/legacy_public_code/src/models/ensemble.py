from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from xgboost import XGBRegressor

def build_ensemble_model(name, random_state=42):
    name = name.upper()
    if name == "RF":
        return RandomForestRegressor(
            n_estimators=300,
            bootstrap=True,
            oob_score=True,
            max_depth=None,
            min_samples_leaf=1,
            random_state=random_state,
            n_jobs=-1,
        )
    if name == "ET":
        return ExtraTreesRegressor(
            n_estimators=250,
            bootstrap=False,
            max_depth=None,
            min_samples_leaf=1,
            random_state=random_state,
            n_jobs=-1,
        )
    if name == "XGB":
        return XGBRegressor(
            n_estimators=100,
            learning_rate=0.05,
            max_depth=3,
            tree_method="hist",
            subsample=0.9,
            colsample_bytree=1.0,
            reg_alpha=0,
            reg_lambda=1,
            random_state=random_state,
            objective="reg:squarederror",
            n_jobs=-1,
        )
    raise ValueError(f"Unknown ensemble model: {name}")
