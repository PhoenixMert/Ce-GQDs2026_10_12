
from __future__ import annotations

import copy
import random
import numpy as np
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler


def set_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


class SequenceRegressor(nn.Module):
    def __init__(self, cell_type: str):
        super().__init__()
        recurrent = nn.GRU if cell_type.upper() == "GRU" else nn.LSTM
        self.recurrent = recurrent(
            input_size=2,
            hidden_size=8,
            num_layers=1,
            batch_first=True,
        )
        self.output = nn.Linear(8, 2)

    def forward(self, x):
        sequence, _ = self.recurrent(x)
        return self.output(sequence)


def build_sequences(frequencies_hz, voltages, c_matrix, g_matrix, indices):
    x_list, y_list = [], []
    for i in indices:
        f_khz = float(frequencies_hz[i]) / 1000.0
        x = np.column_stack([
            voltages.astype(float),
            np.full(len(voltages), np.log10(f_khz), dtype=float),
        ])
        y = np.column_stack([
            np.log10(c_matrix[i].astype(float)),
            np.log10(g_matrix[i].astype(float)),
        ])
        x_list.append(x)
        y_list.append(y)
    return np.stack(x_list), np.stack(y_list)


def predict_lofo_sequence(
    cell_type,
    frequencies_hz,
    voltages,
    c_matrix,
    g_matrix,
    held_idx,
    *,
    seed=42,
):
    """Reconstructed GRU/LSTM pipeline from the supplied reproduction package.

    - one frequency sweep = one sequence (81 voltage points);
    - features: [V, log10(f_kHz)];
    - joint targets: [log10(C), log10(G)];
    - StandardScaler for X and Y across all training sequence points;
    - GRU/LSTM hidden_size=8, one layer;
    - Linear(8, 2) output head;
    - SmoothL1Loss, Adam(lr=0.02);
    - max 60 epochs, patience 10 on training loss.
    """
    set_seed(seed)

    train_idx = [i for i in range(len(frequencies_hz)) if i != held_idx]
    x_train, y_train = build_sequences(
        frequencies_hz, voltages, c_matrix, g_matrix, train_idx
    )

    held_khz = float(frequencies_hz[held_idx]) / 1000.0
    x_test = np.column_stack([
        voltages.astype(float),
        np.full(len(voltages), np.log10(held_khz), dtype=float),
    ])[None, :, :]

    x_scaler = StandardScaler().fit(x_train.reshape(-1, 2))
    y_scaler = StandardScaler().fit(y_train.reshape(-1, 2))

    x_train_scaled = x_scaler.transform(
        x_train.reshape(-1, 2)
    ).reshape(x_train.shape)

    y_train_scaled = y_scaler.transform(
        y_train.reshape(-1, 2)
    ).reshape(y_train.shape)

    x_test_scaled = x_scaler.transform(
        x_test.reshape(-1, 2)
    ).reshape(x_test.shape)

    x_tensor = torch.tensor(x_train_scaled, dtype=torch.float32)
    y_tensor = torch.tensor(y_train_scaled, dtype=torch.float32)
    x_test_tensor = torch.tensor(x_test_scaled, dtype=torch.float32)

    model = SequenceRegressor(cell_type)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.02)
    loss_fn = nn.SmoothL1Loss()

    best_loss = float("inf")
    best_state = None
    stale_epochs = 0
    epochs_trained = 0

    for epoch in range(60):
        epochs_trained = epoch + 1
        model.train()
        optimizer.zero_grad()
        prediction = model(x_tensor)
        loss = loss_fn(prediction, y_tensor)
        loss.backward()
        optimizer.step()

        current = float(loss.item())
        if current < best_loss - 1e-8:
            best_loss = current
            best_state = copy.deepcopy(model.state_dict())
            stale_epochs = 0
        else:
            stale_epochs += 1
            if stale_epochs >= 10:
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    model.eval()
    with torch.no_grad():
        pred_scaled = model(x_test_tensor).cpu().numpy()[0]

    pred = y_scaler.inverse_transform(pred_scaled)
    c_pred = 10.0 ** pred[:, 0]
    g_pred = 10.0 ** pred[:, 1]

    return c_pred, g_pred, {
        "epochs_trained": epochs_trained,
        "best_training_loss": best_loss,
    }
