import numpy as np
from scipy.interpolate import interp1d, PchipInterpolator

def reconstruct_interpolation(frequencies_hz, values_matrix, held_out_index, method):
    """LOFO interpolation in log10(frequency)-log10(target) space.

    values_matrix shape: [n_frequency, n_bias]
    """
    frequencies_hz = np.asarray(frequencies_hz, dtype=float)
    values_matrix = np.asarray(values_matrix, dtype=float)
    train_idx = [i for i in range(len(frequencies_hz)) if i != held_out_index]
    x_train = np.log10(frequencies_hz[train_idx])
    x_test = np.log10(frequencies_hz[held_out_index])

    pred = np.empty(values_matrix.shape[1], dtype=float)
    for j in range(values_matrix.shape[1]):
        y_train = np.log10(values_matrix[train_idx, j])
        if method.lower() == "linear":
            fn = interp1d(
                x_train, y_train, kind="linear",
                fill_value="extrapolate", assume_sorted=True
            )
        elif method.lower() == "pchip":
            fn = PchipInterpolator(x_train, y_train, extrapolate=True)
        else:
            raise ValueError(f"Unknown interpolation method: {method}")
        pred[j] = 10.0 ** float(fn(x_test))
    return pred
