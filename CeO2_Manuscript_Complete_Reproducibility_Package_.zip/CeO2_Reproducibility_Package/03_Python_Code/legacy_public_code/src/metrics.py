import math
import numpy as np
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

def regression_metrics(y_true, y_pred, scale=1.0):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    r2 = r2_score(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_true, y_pred)) * scale
    mae = mean_absolute_error(y_true, y_pred) * scale
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100.0
    return {"R2": r2, "RMSE": rmse, "MAE": mae, "MAPE": mape}
