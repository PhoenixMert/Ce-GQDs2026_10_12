import math
from .config import Q_C, DEVICE_AREA_CM2

def angular_frequency(frequency_hz: float) -> float:
    return 2.0 * math.pi * frequency_hz

def series_resistance(C_F: float, G_S: float, frequency_hz: float) -> float:
    """Nicollian-Brews expression used as Eq. (1) in the manuscript."""
    w = angular_frequency(frequency_hz)
    return G_S / (G_S**2 + (w * C_F)**2)

def g_over_omega(G_S: float, frequency_hz: float) -> float:
    return G_S / angular_frequency(frequency_hz)

def gp_over_omega(Cm_F: float, Gm_S: float, frequency_hz: float, Ci_F: float) -> float:
    """Conductance-method expression shown as Eq. (2) in the manuscript."""
    w = angular_frequency(frequency_hz)
    den = Gm_S**2 + (w * (Ci_F - Cm_F))**2
    return (w * Gm_S * Ci_F**2) / den

def nss_hill_coleman(gp_over_omega_max_F: float, area_cm2: float = DEVICE_AREA_CM2) -> float:
    """Eq. (3): Nss = (Gp/omega)_max / (0.402*q*A)."""
    return gp_over_omega_max_F / (0.402 * Q_C * area_cm2)


def corrected_admittance(Cm_F: float, Gm_S: float, frequency_hz: float, Rs_ohm: float):
    """Standard series-resistance correction used for scientific recomputation."""
    w = angular_frequency(frequency_hz)
    common = Gm_S**2 + (w * Cm_F)**2
    a = Gm_S - common * Rs_ohm
    den = a**2 + (w * Cm_F)**2
    Cc = common * Cm_F / den
    Gc = common * a / den
    return Cc, Gc

def corrected_admittance_legacy_workbook(
    Cm_F: float, Gm_S: float, frequency_hz: float, Rs_ohm: float
):
    """Exact algebra entered in the archived 1 MHz worksheet.

    The worksheet uses pi=3.14 and the expression
    a = Gm - (Gm^2 + (omega*Cm)^2 * Rs),
    i.e. Rs multiplies only the second term as entered in Excel.
    This function exists only to audit/reproduce the archived spreadsheet.
    """
    w = 2.0 * 3.14 * frequency_hz
    common = Gm_S**2 + (w * Cm_F)**2
    a = Gm_S - (Gm_S**2 + (w * Cm_F)**2 * Rs_ohm)
    den = a**2 + (w * Cm_F)**2
    Cc = common * Cm_F / den
    Gc = common * a / den
    return Cc, Gc

def nss_two_frequency_capacitance(
    C_low_F: float, C_high_F: float, Ci_F: float = 3e-10,
    area_cm2: float = DEVICE_AREA_CM2
) -> float:
    """Legacy formula found in the archived workbook Nss column.

    This is included for audit/reproduction only. It is NOT the Hill-Coleman
    formula described in the current manuscript text.
    """
    term_low = 1.0 / (1.0 / C_low_F - 1.0 / Ci_F)
    term_high = 1.0 / (1.0 / C_high_F - 1.0 / Ci_F)
    return (term_low - term_high) / (Q_C * area_cm2)

def nss_two_frequency_capacitance_legacy(
    C_low_F: float, C_high_F: float, Ci_F: float = 3e-10,
    area_cm2: float = DEVICE_AREA_CM2
) -> float:
    """Exact archived-workbook reproduction using q=1.6e-19 C."""
    q_legacy = 1.6e-19
    term_low = 1.0 / (1.0 / C_low_F - 1.0 / Ci_F)
    term_high = 1.0 / (1.0 / C_high_F - 1.0 / Ci_F)
    return (term_low - term_high) / (q_legacy * area_cm2)


def hill_coleman_profile(C_by_frequency_F, G_by_frequency_S, frequencies_hz,
                         Ci_F=3e-10, area_cm2=0.00785):
    """Calculate bias-resolved Hill-Coleman Nss from a frequency sweep.

    For each bias voltage:
      1) calculate Gp/omega at every available frequency;
      2) select max(Gp/omega);
      3) Nss = (Gp/omega)_max / (0.402*q*A).

    Inputs are 2-D arrays with shape [n_frequency, n_bias].
    """
    import numpy as np
    C = np.asarray(C_by_frequency_F, dtype=float)
    G = np.asarray(G_by_frequency_S, dtype=float)
    f = np.asarray(frequencies_hz, dtype=float)

    gpw = np.empty_like(C)
    for i, fi in enumerate(f):
        w = 2.0 * math.pi * fi
        den = G[i]**2 + (w * (Ci_F - C[i]))**2
        gpw[i] = (w * G[i] * Ci_F**2) / den

    imax = np.argmax(gpw, axis=0)
    max_gpw = gpw[imax, np.arange(gpw.shape[1])]
    nss = max_gpw / (0.402 * Q_C * area_cm2)
    peak_frequency_hz = f[imax]
    return nss, max_gpw, peak_frequency_hz, gpw
