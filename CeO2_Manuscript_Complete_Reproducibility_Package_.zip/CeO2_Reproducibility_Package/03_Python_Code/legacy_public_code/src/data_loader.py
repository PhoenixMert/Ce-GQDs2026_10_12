import csv
from collections import defaultdict
from pathlib import Path
from .config import PROCESSED_DIR, FREQUENCIES_HZ, N_BIAS, VOLTAGE_MIN, VOLTAGE_MAX

def load_experimental_long(path: Path | None = None):
    path = path or (PROCESSED_DIR / "experimental_cv_gv_long.csv")
    out = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            out.append({
                "voltage_V": float(row["voltage_V"]),
                "frequency_Hz": int(float(row["frequency_Hz"])),
                "frequency_kHz": float(row["frequency_kHz"]),
                "C_F": float(row["C_F"]),
                "G_over_omega_F": float(row["G_over_omega_F"]),
                "G_S": float(row["G_S"]),
                "Rs_workbook_ohm": float(row["Rs_workbook_ohm"]),
            })
    return out

def validate_dataset(rows):
    errors = []
    expected_n = len(FREQUENCIES_HZ) * N_BIAS
    if len(rows) != expected_n:
        errors.append(f"Expected {expected_n} rows, found {len(rows)}.")

    by_f = defaultdict(list)
    for r in rows:
        by_f[r["frequency_Hz"]].append(r)

    found = tuple(sorted(by_f))
    if found != tuple(sorted(FREQUENCIES_HZ)):
        errors.append(f"Frequency grid mismatch: {found}")

    for f, group in by_f.items():
        if len(group) != N_BIAS:
            errors.append(f"{f} Hz has {len(group)} bias points, expected {N_BIAS}.")
        vv = sorted(x["voltage_V"] for x in group)
        if abs(vv[0] - VOLTAGE_MIN) > 1e-12 or abs(vv[-1] - VOLTAGE_MAX) > 1e-12:
            errors.append(f"{f} Hz voltage range is {vv[0]}..{vv[-1]}.")
        for a,b in zip(vv, vv[1:]):
            if abs((b-a)-0.05) > 1e-10:
                errors.append(f"{f} Hz voltage spacing is not uniformly 0.05 V.")
                break
    return errors
