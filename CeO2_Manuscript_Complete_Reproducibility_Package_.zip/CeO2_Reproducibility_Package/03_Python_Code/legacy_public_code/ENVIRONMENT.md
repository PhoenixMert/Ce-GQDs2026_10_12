# Verified software environment

- `numpy 2.3.5`
- `scipy 1.17.0`
- `scikit-learn 1.8.0`
- `xgboost 3.1.3`
- `torch 2.10.0+cpu`
- `matplotlib 3.10.8`
- `pytest 9.0.2`

These versions correspond to the environment used for the final repository verification.
