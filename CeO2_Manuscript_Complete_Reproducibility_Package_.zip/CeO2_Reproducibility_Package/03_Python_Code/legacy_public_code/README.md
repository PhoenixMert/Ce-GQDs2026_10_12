# Physics-Guided Reconstruction of Frequency-Dependent Electrical Characteristics

This repository contains the experimental data and source code used for the frequency-dependent electrical reconstruction analysis of the Au/CeO2NPs/PEI N-GQDs/n-Si/Au device.

## Dataset
The canonical dataset contains 17 measurement frequencies from 10 kHz to 10 MHz and 81 bias voltages from -2.5 V to +1.5 V, corresponding to 1377 experimental frequency-voltage samples. The original source workbook is retained under `data/raw/`; the canonical machine-readable dataset is under `data/processed/`.

## Models and validation
Seven methods are evaluated using 17-fold leave-one-frequency-out (LOFO) validation: Linear interpolation, PCHIP, Random Forest (RF), Extra Trees (ET), XGBoost (XGB), GRU, and LSTM. In each fold, all 81 bias points from one frequency are held out and the remaining 16 frequencies are used for reconstruction/training.

RF uses 300 trees and ET uses 250 trees with the manuscript settings defined explicitly in the source code. Random seed 42 is used where applicable.

## Recurrent models
Each complete 81-point bias sweep is one recurrent sequence. Inputs are voltage and log10(frequency in kHz); the joint targets are log10(C) and log10(G). Input and target StandardScaler transformations are fitted only on the training frequencies within each LOFO fold. GRU and LSTM use 8 hidden units, one recurrent layer, a two-output linear head, Smooth L1 loss, Adam, learning rate 0.02, maximum 60 epochs, patience 10, and seed 42.

## Physics-guided evaluation
Series resistance Rs is recalculated from reconstructed C and G rather than predicted directly. Interface-state density Nss is calculated from the full reconstructed frequency-dependent C/G surfaces using the Hill-Coleman conductance formulation with Ci = 3e-10 F, contact diameter = 1 mm, q = 1.602176634e-19 C, and factor 0.402. The experimental Hill-Coleman profile reaches approximately 1.718e12 eV^-1 cm^-2 at -0.05 V.

## Installation
```bash
python -m venv .venv
pip install -r requirements.txt
```
The verified package versions are listed in `ENVIRONMENT.md`.

## Full reproduction
```bash
python scripts/01_prepare_dataset.py
python scripts/02_validate_physics.py
python scripts/03_run_lofo_primary_models.py
python scripts/07_run_lofo_dl.py
python scripts/05_reconstruct_rs.py
python scripts/09_compute_hill_coleman_nss.py
python scripts/10_generate_final_tables.py
python scripts/11_generate_final_figures.py
pytest -q
```

Final manuscript-ready tables:
- `results/tables/Table3_CV_FINAL.csv`
- `results/tables/Table4_GV_FINAL.csv`
- `results/tables/Table5_RsV_FINAL.csv`
- `results/tables/Table7_Nss_FINAL.csv`

Final Figures 6-9 are generated as 600-dpi TIFF files under `figures/`. Their plotted numeric values are stored as CSV files under `figures/data/`; convenience Excel copies are under `figures/excel/`.

Figures 6-9 display Experimental + Linear + PCHIP + RF + ET, consistent with the manuscript captions. Experimental data are open black circles and model colors are kept consistent between figures.

## Public-release policy
Only the final canonical analysis, data, outputs, and reproduction scripts are included. Superseded model revisions, historical prediction workbooks, internal audit files, and manuscript change logs are intentionally excluded.
