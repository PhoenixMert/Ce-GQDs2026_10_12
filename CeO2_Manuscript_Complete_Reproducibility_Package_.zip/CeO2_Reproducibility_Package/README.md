# Complete Reproducibility Package

This archive contains the final checked manuscript, original experimental workbook, processed experimental data, prediction-level outputs, all current major-revision analyses, Python source code, every manuscript table, final manuscript figure images, and Excel workbooks supporting each figure.

## Run
```bash
python -m pip install -r 07_Environment/requirements.txt
python 03_Python_Code/current_reproduction/run_all.py
```
For a fast numerical audit without retraining:
```bash
python 03_Python_Code/current_reproduction/recompute_metrics_from_predictions.py
python 03_Python_Code/current_reproduction/verify_manuscript_numbers.py
```

## Data and validation
The experiment contains 17 frequencies (10 kHz–10 MHz) and 81 bias points (−2.5 to +1.5 V), i.e. 1377 points per electrical target. LOFO uses 17 folds; the 15 interior frequencies (30 kHz–7 MHz) are interpolation cases and 10 kHz/10 MHz are endpoint extrapolation cases.

Sparse measured grids are 13, 9, 7 and 5 frequencies, corresponding to 23.53%, 47.06%, 58.82% and 70.59% reductions in measured frequency sweeps. The 5-frequency grid is 10, 50, 300 kHz, 2 and 10 MHz.

Methods: Linear, PCHIP, RF, ET, XGB; GRU/LSTM are retained as LOFO benchmarks. A Nicollian–Brews-type analytical equivalent-circuit baseline is also included. RF/ET/XGB repeated-seed analyses use 11, 22, 33, 42 and 55.

## Metric convention
R² = 1 − Σ(y−ŷ)²/Σ(y−ȳ)². Negative R² values are retained.
RMSE = sqrt(mean((y−ŷ)²)); MAE = mean(|y−ŷ|); MAPE = 100×mean(|(y−ŷ)/y|).
For LOFO/sparse NRMSE, RMSE is normalized separately by the mean experimental value at each reconstructed frequency, expressed as %, and then averaged across omitted frequencies.

## Physics-based analysis
Point-level Rs, Gp/ω and Nss outputs are under `04_Analysis_Data/Derived_Rs_Gp_Nss`. Quantitative Rs metrics are restricted to V >= +1.0 V. Nss is a reconstruction-sensitive diagnostic rather than independently validated absolute ground truth. Sensitivity/error-propagation and frequency-resolution outputs are in `04_Analysis_Data/Nss_Sensitivity`.

## Figures
`06_Figures/Images` contains Figures 1–11 extracted directly from the final manuscript, so there is no ambiguity about the plotted version. `06_Figures/Excel_Data` contains one Excel workbook per figure. Figures 1–3 are schematics, so their Excel files contain captions/provenance metadata instead of fabricated numerical data. Figures 4–11 contain the numerical source/supporting data.

Figure mapping: Fig.4 experimental C–V/G–V; Fig.5 experimental Rs/Nss; Fig.6 LOFO C–V; Fig.7 LOFO G–V; Fig.8 sparse validation; Fig.9 LOFO vs sparse; Fig.10 five-frequency Rs–V; Fig.11 five-frequency Nss.

## Tables
All manuscript tables are under `05_Tables` in both Excel and CSV: Tables 1–5, Table 6(a)/(b), and Table S1.

## Code provenance
`03_Python_Code/legacy_public_code` preserves the earlier project implementation for data loading, LOFO, ensemble models, GRU/LSTM, physics equations, Rs and Hill–Coleman Nss calculations. `03_Python_Code/current_reproduction` adds explicit scripts for the revised 13/9/7/5 sparse-grid reconstruction, recalculation from point-level predictions, manuscript-number verification, and numerical figure regeneration.

The exact stored current-analysis CSV outputs are authoritative for the revised manuscript. The package intentionally distinguishes stored authoritative results from newly regenerated diagnostic outputs.

## Headline verification
The verification script checks key values including five-frequency G PCHIP R²≈0.9959; C Linear R²≈0.9869; C ET R²≈0.9852; G XGB NRMSE=139.844643...%→139.84%; PCHIP Rs R²≈0.9952; PCHIP Nss R²≈0.9582; median |S_C|≈3.29 and |S_G|≈0.225.

## Reproducibility boundary
Everything currently available in the project record needed to audit the final revised manuscript is included. Exact publication PNGs are preserved. Schematic figures have no invented numerical datasets. The revised sparse-grid numerical pipeline can be rerun; legacy code is retained for the original LOFO/DL/physics implementation.


## Supplementary table numbering (revision)
- Table S1: complete frequency-wise LOFO reconstruction performance across all 17 held-out frequencies.
- Table S2: sparse-frequency reconstruction performance for 13-, 9-, 7-, and 5-frequency configurations.
