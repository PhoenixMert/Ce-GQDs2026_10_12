Derived-parameter validation under sparse-frequency reconstruction.
Rs is evaluated only for V>=1.0 V (strong-accumulation analysis window) and only at reconstructed frequencies.
Gp/omega errors are evaluated only at reconstructed frequencies.
Nss is recomputed from the completed 17-frequency sweep (measured frequencies retained; omitted frequencies reconstructed).
Hill-Coleman profile metrics are presented as reconstruction diagnostics; the methodological validity/sensitivity of bias-resolved extraction is treated separately.
