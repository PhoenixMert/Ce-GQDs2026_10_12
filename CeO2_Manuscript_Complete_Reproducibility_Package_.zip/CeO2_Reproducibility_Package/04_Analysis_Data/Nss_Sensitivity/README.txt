Nss sensitivity/error-propagation analysis.
Analytical elasticities are first-order local sensitivities of Gp/omega (and hence Nss) at the selected experimental peak, conditional on no peak-frequency switching.
Finite-difference +/-1% perturbations check the analytical result while allowing peak switching.
Frequency-resolution sensitivity recomputes Hill-Coleman Nss using only the experimentally measured frequencies in each 13/9/7/5 sparse grid, with no reconstruction.
This analysis quantifies sensitivity; it does not resolve the reviewer concern about the domain of validity of a bias-resolved Hill-Coleman profile.
