Physical-consistency diagnostics for sparse-frequency reconstruction.
All metrics are computed from actual experimental/reconstructed C and G.
Positivity metrics use reconstructed points only.
Admittance magnitude/phase errors use reconstructed points only.
Rs preservation is deliberately restricted to the strong-accumulation analysis window V >= 1.0 V to avoid interpreting the Nicollian-Brews Rs expression across depletion/transition bias.
Frequency-dispersion agreement is the percentage of local adjacent-frequency slope directions matching experiment for intervals influenced by at least one reconstructed frequency.
Gp/omega peak metrics compare peak frequency and peak magnitude over the full 17-frequency grid after unmeasured frequencies are reconstructed. Ci=3e-10 F, matching the current repository implementation.
Nss profile metrics are diagnostic only; they do not by themselves validate point-by-point Hill-Coleman use. The extraction-validity issue is handled separately in revision analysis 05/06.
