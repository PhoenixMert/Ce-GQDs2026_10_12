07 - Nicollian-Brews-type analytical physical baseline

Model used
----------
At each bias, a five-parameter single-time-constant equivalent circuit was fit jointly to C(f) and G(f):
  Yp = G0 + j*w*Cinf + j*w*Cit/(1 + j*w*tau)
  Ym = Yp/(1 + Rs*Yp)
with positive Cinf, Cit, tau, G0 and Rs enforced by log-parameterization.

Important interpretation
------------------------
This is a compact Nicollian-Brews-type equivalent-circuit baseline inspired by the reviewer's request. It is NOT claimed to be the unique or exact device physics model. The one-time-constant assumption is deliberately restrictive and therefore acts as a physical analytical comparator rather than a flexible ML model.

Validation
----------
1) 17-fold LOFO: fit 16 frequencies at each bias and predict the held-out frequency.
2) Sparse grids: fit only the manuscript's balanced 13/9/7/5 measured-frequency sets and predict all omitted frequencies.
3) Low endpoint, interior frequencies and high endpoint are summarized separately.

The full-grid fit tables are diagnostic only and must not be presented as out-of-sample validation.
