Repeated-seed robustness analysis for sparse-frequency reconstruction.
Models: RF, ET, XGB.
Seeds: 11, 22, 33, 42, 55 (5 independent runs).
Budgets: 13, 9, 7, 5 measured frequencies.
Targets: C and G.
Metrics: R2, NRMSE normalized by mean absolute experimental value, NMAE normalized by mean absolute experimental value, MAPE.
Linear and PCHIP are deterministic and therefore are not repeated here; their results are in 02_Sparse_Grid_13_9_7_5.
Files:
- repeated_seed_metrics_all.csv: every seed/model/budget/target result.
- repeated_seed_summary.csv: mean +/- sample SD across five seeds.
